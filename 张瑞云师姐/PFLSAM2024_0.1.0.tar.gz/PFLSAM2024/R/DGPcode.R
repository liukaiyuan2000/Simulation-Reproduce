library(purrr)
#' @title Data Generate Process
#'
#' @param R parameter R
#' @param m dimension
#' @param rho parameter rho
#' @param case.DGP DGP case 1-6
#' @param case.var var case 1: homoscedasticity and 2: heteroscedasticity
#' @param time.num number of discrete time points
#'
#' @return a list contain the data
#' @export
#'
#' @examples mydata <- DGP(R = 30, m = 5, rho = 0.25, case.DGP = 1, case.var = 1)
DGP <- function(R, m, rho, case.DGP, case.var, time.num = 100){
  n = R * m
  time.points = (1:time.num - 0.5) / time.num
  #Generating weight matrix
  I_R <- diag(R)
  I_m <- diag(m)#weight
  l_m <- rep(1, m)#vector
  B_m <- (l_m %*% t(l_m) - I_m) / (m - 1)
  Wn <- I_R %x% B_m
  ginv.mat <- solve(diag(n) - rho*Wn)

  lambda.j = (pi*(1:100 - 0.5))^(-2)
  ## jt
  phi.jt  = sqrt(2)*sin(pi * (1:100 - 0.5) %*% t(time.points))
  switch(
    case.DGP,
    {
      ## DGP1
      Zn = matrix(rnorm(n*2), n, 2)
      gamma.t <- sqrt(2)*sin(pi * time.points / 2) + 3*sqrt(2)*sin(3 * pi * time.points / 2)
      eta.nj  <- map(1:n, \(y) map_dbl(lambda.j, \(x) rnorm(1, 0, sd = sqrt(x))))
      Xnt     <- do.call(rbind, map(eta.nj, \(x) colSums(x * phi.jt)))

      I1 = rowSums(Zn) + colMeans(t(Xnt)*gamma.t)
    },
    {
      ## DGP2
      Zn = matrix(runif(n*2), n, 2)
      gamma.t <- sqrt(2)*sin(pi * time.points / 2) + 3*sqrt(2)*sin(3 * pi * time.points / 2)
      eta.nj  <- map(1:n, \(y) map_dbl(lambda.j, \(x) rnorm(1, 0, sd = sqrt(x))))
      Xnt    <- do.call(rbind, map(eta.nj, \(x) colSums(x * phi.jt)))

      I1 = rowSums(Zn) + colMeans(t(Xnt)*gamma.t)
    },
    {
      ## DGP3
      Zn = matrix(rnorm(n*5), n, 5)
      gamma.t <- sqrt(2)*sin(pi * time.points / 2) + 3*sqrt(2)*sin(3 * pi * time.points / 2)
      eta.nj  <- map(1:n, \(y) map_dbl(lambda.j, \(x) rnorm(1, 0, sd = sqrt(x))))
      Xnt     <- do.call(rbind, map(eta.nj, \(x) colSums(x * phi.jt)))

      temp1 = colMeans(t(Xnt)*gamma.t)
      temp2 = rowSums(Zn)
      I1 = 2*temp2 + temp1 + 0.8 * (cos(0.6*pi*temp1)) + sin(temp2)
    },
    {
      ## DGP4
      Zn = matrix(rnorm(n*2), n, 2)
      gamma.t <- sqrt(2)*sin(pi * time.points / 2) + 3*sqrt(2)*sin(3 * pi * time.points / 2)
      eta.nj  <- map(1:n, \(y) map_dbl(lambda.j, \(x) rnorm(1, 0, sd = sqrt(x))))
      Xnt     <- do.call(rbind, map(eta.nj, \(x) colSums(x * phi.jt)))

      temp1 = colMeans(t(Xnt)*gamma.t)
      I1 = Zn[, 1] + 2*Zn[, 2] + temp1 + 0.25 * (rowSums(Zn) + exp(temp1))
    },
    {
      ## DGP5
      Zn = matrix(rnorm(n*2), n, 2)
      gamma.t <- sqrt(2)*sin(pi * time.points / 2) + 3*sqrt(2)*sin(3 * pi * time.points / 2)
      eta.nj  <- map(1:n, \(y) map_dbl(lambda.j, \(x) rnorm(1, 0, sd = sqrt(x))))
      Xnt     <- do.call(rbind, map(eta.nj, \(x) colSums(x * phi.jt)))

      I1 = rowSums(Zn) + colMeans(t(Xnt)*gamma.t)
    },
    {
      ## DGP6
      Zn = matrix(runif(n*3), n, 3)
      gamma.t <- sin(pi*time.points/2) + 0.5*sin(3*pi*time.points/2) + 0.25*sin(5*pi*time.points/2)
      eta.nj  <- map(1:n, \(y) map_dbl(lambda.j, \(x) rnorm(1, 0, sd = sqrt(x))))
      Xnt     <- do.call(rbind, map(eta.nj, \(x) colSums(x * phi.jt)))

      I1 = rowSums(Zn) + Zn[, 1] + colMeans(t(Xnt)*gamma.t)
    }
  )
  eps <- switch(
    case.var,
    rnorm(n),
    sqrt(2)*(1 + Zn[, 1])*rnorm(n)
  )
  Yn = ginv.mat %*% (I1 + eps)

  return(
    list(
      Wn = Wn, Zn = Zn, Xnt = Xnt, Yn = Yn
    )
  )
}

#' @title calculate phi.hat
#'
#' @param Xnt a n*T matrix
#'
#' @return Phi and t2.tilde
#' @export
#'
#' @examples A = phi.hat(Xnt)
phi.hat <- function(Xnt)
{
  t.num = ncol(Xnt)
  n = nrow(Xnt)
  # Calculate phi_hat
  K_hat_st <- t(Xnt) %*% Xnt / (n - 1)
  # Spectral decomposition
  eigen_decomp <- eigen(K_hat_st)
  # Extract eigenvalue
  eigenvalues <- eigen_decomp$values
  # Extract feature vector
  eigenvectors <- eigen_decomp$vectors
  # Calculate the sum of the eigenvalues
  total_variance <- sum(eigenvalues)
  # Sort the eigenvalues by size
  sorted_indices <- order(eigenvalues, decreasing = TRUE)
  sorted_eigenvalues <- eigenvalues[sorted_indices]
  sorted_eigenvectors <- eigenvectors[, sorted_indices]
  # Calculate the cumulative proportion of eigenvalues
  variance_ratio <- cumsum(sorted_eigenvalues) / total_variance
  # Select the eigenvalues with a cumulative proportion of not less than 80%
  selected_indices <- min(which(variance_ratio >= 0.95))
  # sorted_eigenvalues[selected_indices]
  lambda_hat <-  sorted_eigenvalues[1:selected_indices]
  # sorted_eigenvectors[, selected_indices]
  phi <- sorted_eigenvectors[, 1:selected_indices]
  r <- 0.95
  cumulative_variance <- cumsum(sorted_eigenvalues^2) / sum(sorted_eigenvalues^2)
  j_n <- min(which(cumulative_variance >= r))
  eta <- rep(0, j_n)
  h_2_tilde <- rep(0, t.num)
  for(i in 1:j_n)
  {
    eta[i] <- rnorm(1, 0, sqrt(lambda_hat[j_n]))
    h_2_tilde <- h_2_tilde+eta[i]*sorted_eigenvectors[, i]
  }
  #Calculate Phi
  Phi <- Xnt %*% phi / t.num

  return(list(Phi = Phi, h_2_tilde = h_2_tilde))
}

